﻿using System.Data;
using System.Data.SqlClient;
using CarManagementAPI.Models;
using CarManagementAPI.Utils;

namespace CarManagementAPI
{
    public class CarsService : ICarsService
    {
        private readonly IConfiguration _configuration;
        private readonly string? _ConString;

        public CarsService(IConfiguration configuration)
        {
            _configuration = configuration;
            _ConString = configuration.GetConnectionString("DefaultConnection");
        }

        public CarsList GetAllCars()
        {
            CarsList Model = new CarsList();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_GetAllCars", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection.Open();
                        using (IDataReader dataReader = cmd.ExecuteReader())
                        {
                            Model.carsList = Utils.Mapper.DataReaderMapToList<CarModel>(dataReader);
                        }
                        cmd.Connection.Close();
                        return Model;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BrandList GetAllBrands()
        {
            BrandList Model = new BrandList();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_GetAllBrands", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection.Open();
                        using (IDataReader dataReader = cmd.ExecuteReader())
                        {
                            Model.brandList = Utils.Mapper.DataReaderMapToList<BrandModel>(dataReader);
                        }
                        cmd.Connection.Close();
                        return Model;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public ClassList GetAllClass()
        {
            ClassList Model = new ClassList();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_GetAllClass", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection.Open();
                        using (IDataReader dataReader = cmd.ExecuteReader())
                        {
                            Model.classList = Utils.Mapper.DataReaderMapToList<ClassModel>(dataReader);
                        }
                        cmd.Connection.Close();
                        return Model;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CarModel GetCarDetailsByID(int carId)
        {
            CarModel Model = new CarModel();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_GetCarDetailsByID", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int)).Value = carId;
                        cmd.Connection.Open();
                        using (IDataReader dataReader = cmd.ExecuteReader())
                        {
                            Model = Utils.Mapper.ConvertTOEntity<CarModel>(dataReader);
                        }
                        cmd.Connection.Close();
                        return Model;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public bool DeleteCar(int carId)
        {
            CarModel Model = new CarModel();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_DeleteCarByID", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int)).Value = carId;
                        cmd.Connection.Open();
                        cmd.ExecuteNonQuery();
                        cmd.Connection.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public bool InsertUpdateCar(CarModel car)
        {
            //Car Model = new Car();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_InsertUpdate_Car", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (car.ID != null && car.ID > 0)
                            cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int)).Value = car.ID;
                        else
                            cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int)).Value = 0;

                        cmd.Parameters.Add(new SqlParameter("@BrandID", SqlDbType.Int)).Value = car.BrandID;
                        cmd.Parameters.Add(new SqlParameter("@ClassID", SqlDbType.Int)).Value = car.ClassID;
                        cmd.Parameters.Add(new SqlParameter("@ModelName", SqlDbType.NVarChar)).Value = car.ModelName;
                        cmd.Parameters.Add(new SqlParameter("@ModelCode", SqlDbType.NVarChar)).Value = car.ModelCode;
                        cmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar)).Value = car.Description;
                        cmd.Parameters.Add(new SqlParameter("@Features", SqlDbType.NVarChar)).Value = car.Features;
                        cmd.Parameters.Add(new SqlParameter("@Price", SqlDbType.Decimal)).Value = car.Price;
                        cmd.Parameters.Add(new SqlParameter("@DateOfManufacturing", SqlDbType.Date)).Value = car.DateOfManufacturing;
                        cmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit)).Value = car.IsActive;
                        cmd.Parameters.Add(new SqlParameter("@OrderBy", SqlDbType.Int)).Value = car.OrderBy;




                        cmd.Connection.Open();
                        cmd.ExecuteNonQuery();
                        cmd.Connection.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
