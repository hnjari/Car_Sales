﻿using CarManagementAPI.Models;
using System.Security.Cryptography.X509Certificates;

namespace CarManagementAPI
{
    public interface ICarsService
    {
        public CarsList GetAllCars();
        public BrandList GetAllBrands();
        public ClassList GetAllClass();

        public CarModel GetCarDetailsByID(int id);

        public bool DeleteCar(int id);

        public bool InsertUpdateCar(CarModel car);

    }
}
