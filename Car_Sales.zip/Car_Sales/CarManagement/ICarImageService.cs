﻿using CarManagementAPI.Models;
using System.Security.Cryptography.X509Certificates;

namespace CarManagementAPI
{
    public interface ICarImageService
    {
        public CarImageList GetAllCarImages(int CarID);
        public bool AddCarImage(int CarID, string ImageName);
        public bool DeleteCarImage(int CarImageID);


    }
}
