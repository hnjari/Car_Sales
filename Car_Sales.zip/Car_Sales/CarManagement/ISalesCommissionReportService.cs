﻿using CarManagementAPI.Models;
using System.Security.Cryptography.X509Certificates;

namespace CarManagementAPI
{
    public interface ISalesCommissionReportService
    {
       
        public List<Salesman_Commission_Report> Get_Salesman_Commission_Report();


    }
}
