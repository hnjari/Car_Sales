using CarManagementAPI;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddScoped<ICarsService, CarsService>();
builder.Services.AddScoped<ICarImageService, CarImageService>();
builder.Services.AddScoped<ISalesCommissionReportService, SalesCommissionReportService>();
builder.Services.AddControllers();
builder.Services.AddSwaggerGen();
var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    if (!app.Environment.IsDevelopment())
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Car API");
        c.RoutePrefix = string.Empty;
    }
});

// Configure the HTTP request pipeline.

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
