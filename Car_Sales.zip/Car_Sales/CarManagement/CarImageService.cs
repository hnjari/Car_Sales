﻿using System.Data;
using System.Data.SqlClient;
using CarManagementAPI.Models;
using CarManagementAPI.Utils;

namespace CarManagementAPI
{
    public class CarImageService : ICarImageService
    {
        private readonly IConfiguration _configuration;
        private readonly string? _ConString;

        public CarImageService(IConfiguration configuration)
        {
            _configuration = configuration;
            _ConString = configuration.GetConnectionString("DefaultConnection");
        }

        public CarImageList GetAllCarImages(int CarID)
        {
			CarImageList Model = new CarImageList();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_GetAllCarImages", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.Add(new SqlParameter("@CarID", SqlDbType.Int)).Value = CarID;
						cmd.Connection.Open();
                        using (IDataReader dataReader = cmd.ExecuteReader())
                        {
                            Model.carImageList = Utils.Mapper.DataReaderMapToList<CarImageModel>(dataReader);
                        }
                        cmd.Connection.Close();
                        return Model;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

		public bool AddCarImage(int CarID, string ImageName)
		{
			//Car Model = new Car();
			try
			{
				using (SqlConnection Con = new SqlConnection(_ConString))
				{
					using (SqlCommand cmd = new SqlCommand("usp_AddCarImage", Con))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						
						cmd.Parameters.Add(new SqlParameter("@CarID", SqlDbType.Int)).Value = CarID;
						cmd.Parameters.Add(new SqlParameter("@ImageName", SqlDbType.NVarChar)).Value = ImageName;

						cmd.Connection.Open();
						cmd.ExecuteNonQuery();
						cmd.Connection.Close();
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public bool DeleteCarImage(int CarImageID)
        {
            CarModel Model = new CarModel();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_DeleteCarImageByID", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int)).Value = CarImageID;
                        cmd.Connection.Open();
                        cmd.ExecuteNonQuery();
                        cmd.Connection.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
