﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Data;
using CarManagementAPI.Models;
using CarManagementAPI.Utils;

namespace CarManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
       
        private readonly ICarsService _ICarsService;
        private readonly ICarImageService _ICarImageService;
        private Response _response;

        public CarsController(IConfiguration configuration, ICarsService ICarsService, ICarImageService ICarImageService)
        {
           
            _ICarsService = ICarsService;
            _ICarImageService = ICarImageService;
			_response = new Response();

        }

        #region Get Cars List
        [HttpGet]
        [Route("CarsList")]
        public Response CarsList()
        {
            try
            {
                CarsList carList = new CarsList();
                carList = _ICarsService.GetAllCars();
                _response.Result = carList;
            }
            catch (Exception ex)
            {

                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;

        }
        #endregion


        #region Get Brand List
        [HttpGet]
        [Route("BrandList")]
        public Response BrandList()
        {
            try
            {
                BrandList List = new BrandList();
                List = _ICarsService.GetAllBrands();
                _response.Result = List;
            }
            catch (Exception ex)
            {

                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;

        }
        #endregion

        #region Get Class List
        [HttpGet]
        [Route("ClassList")]
        public Response ClassList()
        {
            try
            {
                ClassList List = new ClassList();
                List = _ICarsService.GetAllClass();
                _response.Result = List;
            }
            catch (Exception ex)
            {

                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;

        }
        #endregion


        #region Get Car By CarID
        [HttpGet]
        [Route("GetCarDetailsByID/{id:int}")]
        public Response GetCarDetailsByID(int id)
        {
            try
            {
                CarModel Car = new CarModel();
                Car = _ICarsService.GetCarDetailsByID(id);
                _response.Result = Car;

            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }
        #endregion


        #region Delete Car By CarID
        [HttpPost]
        [Route("DeleteCar/{id:int}")]
        public Response DeleteCar(int id)
        {
            try
            {
                _ICarsService.DeleteCar(id);
                _response.IsSuccess = true;

            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }
        #endregion


        #region InsertUpdateCar
        [HttpPost]
        [Route("InsertUpdateCar")]
        public Response InsertUpdateCar([FromBody] CarModel car)
        {
            try
            {
                _ICarsService.InsertUpdateCar(car);
                _response.IsSuccess = true;

            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }
        #endregion
    }
}
