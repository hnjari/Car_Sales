﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Data;
using CarManagementAPI.Models;
using CarManagementAPI.Utils;

namespace CarManagementAPI.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class CarImageController : ControllerBase
	{
		private readonly ICarImageService _ICarImageService;
		private Response _response;

		public CarImageController(IConfiguration configuration, ICarImageService ICarImageService)
		{

			_ICarImageService = ICarImageService;
			_response = new Response();

		}

		#region Get Car Images
		[HttpGet]
		[Route("GetCarImages/{CarID:int}")]
		public Response GetCarImages(int CarID)
		{
			try
			{
				CarImageList carImageList = new CarImageList();
				carImageList = _ICarImageService.GetAllCarImages(CarID);
				_response.Result = carImageList;
			}
			catch (Exception ex)
			{

				_response.IsSuccess = false;
				_response.Message = ex.Message;
			}
			return _response;

		}
		#endregion


		#region Add Car Image
		[HttpPost]
		[Route("AddCarImage/{CarID:int}/{ImageName}")]
		public Response AddCarImage(int CarID,string ImageName)
		{
			try
			{
				_ICarImageService.AddCarImage(CarID, ImageName);
				_response.IsSuccess = true;

			}
			catch (Exception ex)
			{
				_response.IsSuccess = false;
				_response.Message = ex.Message;
			}
			return _response;

		}
        #endregion

        #region Delete Car Image
        [HttpPost]
        [Route("DeleteCarImage/{id:int}")]
        public Response DeleteCarImage(int id)
        {
            try
            {
                _ICarImageService.DeleteCarImage(id);
                _response.IsSuccess = true;

            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
            }
            return _response;
        }
        #endregion

    }
}
