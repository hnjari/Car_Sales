﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Data;
using CarManagementAPI.Models;
using CarManagementAPI.Utils;

namespace CarManagementAPI.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class SalesCommissionReportController : ControllerBase
	{
		private readonly ISalesCommissionReportService _ISalesCommissionReportService;
		private Response _response;

		public SalesCommissionReportController(IConfiguration configuration, ISalesCommissionReportService ISalesCommissionReportService)
		{

            _ISalesCommissionReportService = ISalesCommissionReportService;
			_response = new Response();

		}

		#region Get Car Images
		[HttpGet]
		[Route("Get_Salesman_Commission_Report")]
		public Response Get_Salesman_Commission_Report()
		{
			try
			{
                List<Salesman_Commission_Report> rep_list = new List<Salesman_Commission_Report>();
                rep_list = _ISalesCommissionReportService.Get_Salesman_Commission_Report();
				_response.Result = rep_list;
			}
			catch (Exception ex)
			{

				_response.IsSuccess = false;
				_response.Message = ex.Message;
			}
			return _response;

		}
		#endregion


		

    }
}
