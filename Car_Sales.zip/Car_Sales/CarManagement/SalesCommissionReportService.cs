﻿using System.Data;
using System.Data.SqlClient;
using CarManagementAPI.Models;
using CarManagementAPI.Utils;

namespace CarManagementAPI
{
    public class SalesCommissionReportService : ISalesCommissionReportService
    {
        private readonly IConfiguration _configuration;
        private readonly string? _ConString;

        public SalesCommissionReportService(IConfiguration configuration)
        {
            _configuration = configuration;
            _ConString = configuration.GetConnectionString("DefaultConnection");
        }



        public List<Salesman_Commission_Report> Get_Salesman_Commission_Report()
        {
            Salesman_Commission_ReportList Model = new Salesman_Commission_ReportList();
            try
            {
                using (SqlConnection Con = new SqlConnection(_ConString))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_Generate_Salesman_Commission_Report", Con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
						
						cmd.Connection.Open();
                        using (IDataReader dataReader = cmd.ExecuteReader())
                        {
                            Model.reportList = Utils.Mapper.DataReaderMapToList<Salesman_Commission_Report_Model_DB>(dataReader);
                        }
                        cmd.Connection.Close();

                        List<Salesman_Commission_Report> rep_list = new List<Salesman_Commission_Report>();
                        foreach (var m in  Model.reportList)
                        {
                            Salesman_Commission_Report rep = new Salesman_Commission_Report();
                            rep.SalesPersonName = m.SalesPersonName;
                            rep.AdditionalCommission = m.Additional_Commission;
                            Audi audi= new Audi();
                            audi.Fixed_Commission = m.Audi_FixedCommission;
                            audi.A_Class_Commission = m.Audi_ClassA_Commission;
                            audi.B_Class_Commission = m.Audi_ClassB_Commission;
                            audi.C_Class_Commission = m.Audi_ClassC_Commission;
                            audi.Total_Commission = m.Audi_FixedCommission + m.Audi_ClassA_Commission + m.Audi_ClassB_Commission + m.Audi_ClassC_Commission;
                            rep.audi = audi;

                            Jaguar jaguar = new Jaguar();
                            jaguar.Fixed_Commission = m.Jaguar_FixedCommission;
                            jaguar.A_Class_Commission = m.Jaguar_ClassA_Commission;
                            jaguar.B_Class_Commission = m.Jaguar_ClassB_Commission;
                            jaguar.C_Class_Commission = m.Jaguar_ClassC_Commission;
                            jaguar.Total_Commission = m.Jaguar_FixedCommission + m.Jaguar_ClassA_Commission + m.Jaguar_ClassB_Commission + m.Jaguar_ClassC_Commission;
                            rep.jaguar = jaguar;

                            Rover rover = new Rover();
                            rover.Fixed_Commission = m.Rover_FixedCommission;
                            rover.A_Class_Commission = m.Rover_ClassA_Commission;
                            rover.B_Class_Commission = m.Rover_ClassB_Commission;
                            rover.C_Class_Commission = m.Rover_ClassC_Commission;
                            rover.Total_Commission = m.Rover_FixedCommission + m.Rover_ClassA_Commission + m.Rover_ClassB_Commission + m.Rover_ClassC_Commission;
                            rep.rover = rover;


                            Renault renault = new Renault();
                            renault.Fixed_Commission = m.Renault_FixedCommission;
                            renault.A_Class_Commission = m.Renault_ClassA_Commission;
                            renault.B_Class_Commission = m.Renault_ClassB_Commission;
                            renault.C_Class_Commission = m.Renault_ClassC_Commission;
                            renault.Total_Commission = m.Renault_FixedCommission + m.Renault_ClassA_Commission + m.Renault_ClassB_Commission + m.Renault_ClassC_Commission;
                            rep.renault = renault;

                            rep.TotalNetCommission = rep.audi.Total_Commission + rep.jaguar.Total_Commission + rep.rover.Total_Commission + rep.renault.Total_Commission + m.Additional_Commission;
                            rep_list.Add(rep);
                        }
                        return rep_list;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

		
    }
}
