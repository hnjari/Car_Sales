﻿using Car_Sales_WebApp.Models;
using Car_Sales_WebApp.Services.Interface;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Data;
using System.Diagnostics;
using System.Reflection;

namespace Car_Sales_WebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ICarService _carService;
        private readonly ISalesCommissionReportService _salesCommissionReportService;

        public HomeController(ILogger<HomeController> logger, ICarService carService, ISalesCommissionReportService salesCommissionReportService)
        {
            _logger = logger;
            _carService = carService;
            _salesCommissionReportService = salesCommissionReportService;
        }

        public async Task<IActionResult> Index()
        {
            List<CarModel>? list = new();

            Response? response = await _carService.GetAllCarsAsync();

            if (response != null && response.IsSuccess)
            {
                string jsonstring = JsonConvert.SerializeObject(response.Result);
                jsonstring = jsonstring.Replace("{\"carsList\":", "");
                jsonstring = jsonstring.Remove(jsonstring.Length - 1);
                list = JsonConvert.DeserializeObject<List<CarModel>>(jsonstring);

            }
            else
            {
                TempData["error"] = response?.Message;
            }

            return View(list);
        }

        private  List<BrandModel> GetBrands()
        {
            List<BrandModel>? list = new();

            Response? response =  _carService.GetAllBrands();

            if (response != null && response.IsSuccess)
            {
                string jsonstring = JsonConvert.SerializeObject(response.Result);
                jsonstring = jsonstring.Replace("{\"brandList\":", "");
                jsonstring = jsonstring.Remove(jsonstring.Length - 1);
                list = JsonConvert.DeserializeObject<List<BrandModel>>(jsonstring);
                return list;
            }
            else
            {
                TempData["error"] = response?.Message;
            }
            return null;
           
        }

        private  List<ClassModel> GetClass()
        {
            List<ClassModel>? list = new();

            Response? response =  _carService.GetAllClass();

            if (response != null && response.IsSuccess)
            {
                string jsonstring = JsonConvert.SerializeObject(response.Result);
                jsonstring = jsonstring.Replace("{\"classList\":", "");
                jsonstring = jsonstring.Remove(jsonstring.Length - 1);
                list = JsonConvert.DeserializeObject<List<ClassModel>>(jsonstring);
                return list;
            }
            else
            {
                TempData["error"] = response?.Message;
            }
            return null;

        }

        private CarModel GetCarDetailsByID(int ID)
        {
            CarModel list = new();

            Response? response = _carService.GetCarDetailsByID(ID);

            if (response != null && response.IsSuccess)
            {
                string jsonstring = JsonConvert.SerializeObject(response.Result);
                //jsonstring = jsonstring.Replace("{\"classList\":", "");
                //jsonstring = jsonstring.Remove(jsonstring.Length - 1);
                list = JsonConvert.DeserializeObject<CarModel>(jsonstring);
                return list;
            }
            else
            {
                TempData["error"] = response?.Message;
            }
            return null;

        }
        public async Task<IActionResult> CarDelete(int ID)
		{
			Response? response = await _carService.DeleteCarAsync(ID);

			if (response != null && response.IsSuccess)
			{
				TempData["success"] = "Car deleted successfully";
				return RedirectToAction(nameof(Index));
			}
			else
			{
                TempData["error"] = "Due to images of Car exists so this can not be deleted. Please delete all the images first!";
			}
            return RedirectToAction(nameof(Index));
        }

		public async Task<IActionResult> CarCreateUpdate(int ID=0)
		{
            var brands = GetBrands();
            var vbg_brands = new SelectList(brands.OrderBy(l => l.BrandName).ToDictionary(us => us.ID, us => us.BrandName), "Key", "Value");

            var Classes = GetClass();
            var vbg_classes = new SelectList(Classes.OrderBy(l => l.Class).ToDictionary(us => us.ID, us => us.Class), "Key", "Value");

            ViewBag.BrandList = vbg_brands;
            ViewBag.ClassList = vbg_classes;
            CarModel model = new CarModel();
            if(ID> 0)
            {
                model = GetCarDetailsByID(ID);
            }
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CarCreateUpdate(CarModel model)
        {
            model.IsActive = true;
            model.OrderBy = 1;
            model.Class = "x";
            model.BrandName= "y";

            if (ModelState.IsValid)
            {
                Response? response = await _carService.CreateCarAsync(model);

                if (response != null && response.IsSuccess)
                {
                    if(model.ID> 0)
                    {
                        TempData["success"] = "Car updated successfully";
                    } else
                    {
                        TempData["success"] = "Car added successfully";
                    }
                    
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    TempData["error"] = response?.Message;
                }
            }

            var brands = GetBrands();
            var vbg_brands = new SelectList(brands.OrderBy(l => l.BrandName).ToDictionary(us => us.ID, us => us.BrandName), "Key", "Value");

            var Classes = GetClass();
            var vbg_classes = new SelectList(Classes.OrderBy(l => l.Class).ToDictionary(us => us.ID, us => us.Class), "Key", "Value");

            ViewBag.BrandList = vbg_brands;
            ViewBag.ClassList = vbg_classes;
            return View(model);
        }

        public async Task<IActionResult> Sales_Commission_Report()
        {
            List<Salesman_Commission_Report> list = new();
            
            Response? response = await  _salesCommissionReportService.Get_Salesman_Commission_ReportAsync();
            

            if (response != null && response.IsSuccess)
            {
                string jsonstring = JsonConvert.SerializeObject(response.Result);

                list = JsonConvert.DeserializeObject<List<Salesman_Commission_Report>>(jsonstring);
                
                //list.carImageList = JsonConvert.DeserializeObject<List<CarImageModel>>(jsonstring_res1).ToList();
                return View(list);
            }
            else
            {
                TempData["error"] = response?.Message;
            }
            

            return View(list);


            //return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}