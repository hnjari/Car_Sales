﻿using Car_Sales_WebApp.Models;
using Car_Sales_WebApp.Services.Interface;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Collections.Generic;


namespace Car_Sales_WebApp.Controllers
{
	public class ManageImageController : Controller
	{
		private readonly ICarService _carService;
		private readonly ICarImageService _carImageService;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public ManageImageController(ICarService carService, ICarImageService carImageService, IWebHostEnvironment webHostEnvironment)
		{
			_carService = carService;
			_carImageService = carImageService;
            _webHostEnvironment = webHostEnvironment;
        }
		public async Task<IActionResult> Index(int ID)
		{
			CarImages list = new();

			Response? response = _carService.GetCarDetailsByID(ID);
			Response? response1 = await _carImageService.GetAllCarImageAsync(ID);

			if (response != null && response.IsSuccess && response1 != null && response1.IsSuccess)
			{
				string jsonstring = JsonConvert.SerializeObject(response.Result);
			
				list.CarModel= JsonConvert.DeserializeObject<CarModel>(jsonstring);
				string jsonstring_res1 = JsonConvert.SerializeObject(response1.Result);
				jsonstring_res1 = jsonstring_res1.Replace("{\"carImageList\":", "");
				jsonstring_res1 = jsonstring_res1.Remove(jsonstring_res1.Length - 1);
				list.carImageList = JsonConvert.DeserializeObject<List<CarImageModel>>(jsonstring_res1).ToList();
				return View(list);
			}
			else
			{
				TempData["error"] = response?.Message;
			}
			

			return View(list);
		}

        [HttpPost]
        public async Task<IActionResult> Index(CarImages model)
        {
            string FileExtension = Path.GetExtension(model.ImageFile.FileName);
            var ValidFormats = new List<string> { ".jpg", ".jpeg", ".png" };
            if (ValidFormats.Contains(FileExtension, StringComparer.OrdinalIgnoreCase))
            {
                string imgName = model.CarID + "_" + DateTime.Now.ToString("yyyyMMdd-hhmmss") + FileExtension;
                //string imgName = model.CarID + "_" + "aaa";

                Response? response = await _carImageService.AddCarImageAsync(model.CarID, imgName);

                if (response != null && response.IsSuccess)
                {
                   

                    if (model.ImageFile != null)
                    {
                            
                            var rootPath = _webHostEnvironment.WebRootPath.ToLower();
                            string UploadPath = rootPath + "/CarImages/" + imgName;

                            using (var stream = new FileStream(UploadPath, FileMode.Create))
                            {
                                model.ImageFile.CopyTo(stream);
                            }


                    }

                    TempData["success"] = "Car image is added successfully";
                } 
            else
            {
                TempData["error"] = "Invalid format of image file!";
                return RedirectToAction("Index");

            }

            
            }
          

            return RedirectToAction("Index");
        }


        public async Task<IActionResult> DeleteCarImage(string ID)
        {
            int ImageID = Convert.ToInt32(ID.Split(':')[0]);
            string ImageName = ID.Split(':')[1];
            int CarID = Convert.ToInt32(ID.Split(':')[2]);

            Response? response = await _carImageService.DeleteCarImageAsync(ImageID);

            if (response != null && response.IsSuccess)
            {
                

                var rootPath = _webHostEnvironment.WebRootPath.ToLower();
                string UploadPath = rootPath + "/CarImages/" + ImageName;
                System.IO.File.Delete(UploadPath);

                TempData["success"] = "Car image is deleted successfully";

                return RedirectToAction("Index", new { id = CarID });
            }
            else
            {
                TempData["error"] = "Due to technichal issue, Car's image is not deleted. Please try again!";
            }
            return RedirectToAction("Index", new { id = CarID });


        }
    }
}
