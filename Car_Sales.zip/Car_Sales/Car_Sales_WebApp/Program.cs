using Car_Sales_WebApp.Models;
using Car_Sales_WebApp.Services.Interface;
using Car_Sales_WebApp.Services.Service;
using Car_Sales_WebApp.Models;
using Car_Sales_WebApp.Services;
using Car_Sales_WebApp;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient<ICarService, CarService>();
SD.CarManagementAPIBase = builder.Configuration["ServiceUrls:CarManagementAPI"];
builder.Services.AddScoped<IBaseService, BaseService>();
builder.Services.AddScoped<ICarService, CarService>();
builder.Services.AddScoped<ICarImageService, CarImageService>();
builder.Services.AddScoped<ISalesCommissionReportService, SalesCommissionReportService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

//app.UseMiddleware<GlobalExceptionMiddleware>();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
