﻿using System.ComponentModel.DataAnnotations;
using System.Net.Mime;
using System.Security.AccessControl;


namespace Car_Sales_WebApp.Models
{
    public class Response
    {
        public object? Result { get; set; }
        public bool IsSuccess { get; set; } = true;
        public string Message { get; set; } = "";
    }

    public class CarModel
    {
        public int? ID { get; set; }
        public int BrandID { get; set; }

        public string? BrandName { get; set; }

        public int ClassID { get; set; }

        public string? Class { get; set; }
       
        public string ModelName { get; set; }

        public string ModelCode { get; set; }

        public string Description { get; set; }


        public string Features { get; set; }

        public decimal Price { get; set; }

        public DateTime DateOfManufacturing { get; set; }

        public bool? IsActive { get; set; }

        public int? OrderBy { get; set; }

    }

    public class BrandModel
    {
        public int? ID { get; set; }


        public string BrandName { get; set; }



    }
    public class ClassModel
    {
        public int? ID { get; set; }


        public string Class { get; set; }



    }

	public class CarImageModel
	{
		public int ID { get; set; }

		public int CarID { get; set; }
		public string ImageName { get; set; }



	}
	public class CarImageList
	{
		public List<CarImageModel>? carImageList { get; set; }
	}
	public class CarImages
    {
        public CarModel CarModel { get; set; }
		public List<CarImageModel>? carImageList { get; set; }

        public int CarID { get; set; }
        public IFormFile ImageFile { get; set; }
    }


    public class Salesman_Commission_Report
    {
        public string SalesPersonName { get; set; }
        public decimal TotalNetCommission { get; set; }
        public decimal AdditionalCommission { get; set; }

        public Audi audi { get; set; }

        public Jaguar jaguar { get; set; }

        public Rover rover { get; set; }

        public Renault renault { get; set; }


    }

    public class Audi
    {
        public decimal Fixed_Commission { get; set; }
        public decimal A_Class_Commission { get; set; }
        public decimal B_Class_Commission { get; set; }
        public decimal C_Class_Commission { get; set; }

        public decimal Total_Commission { get; set; }
    }

    public class Jaguar
    {
        public decimal Fixed_Commission { get; set; }
        public decimal A_Class_Commission { get; set; }
        public decimal B_Class_Commission { get; set; }
        public decimal C_Class_Commission { get; set; }

        public decimal Total_Commission { get; set; }
    }


    public class Rover
    {
        public decimal Fixed_Commission { get; set; }
        public decimal A_Class_Commission { get; set; }
        public decimal B_Class_Commission { get; set; }
        public decimal C_Class_Commission { get; set; }

        public decimal Total_Commission { get; set; }
    }

    public class Renault
    {
        public decimal Fixed_Commission { get; set; }
        public decimal A_Class_Commission { get; set; }
        public decimal B_Class_Commission { get; set; }
        public decimal C_Class_Commission { get; set; }

        public decimal Total_Commission { get; set; }
    }
}
