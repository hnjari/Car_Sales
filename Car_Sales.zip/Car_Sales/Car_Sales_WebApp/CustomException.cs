﻿namespace Car_Sales_WebApp
{
	public class CustomException : Exception
	{
		public CustomException(string message) : base(message)
		{
		}
	}
}
