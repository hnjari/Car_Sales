﻿using Car_Sales_WebApp.Models;
using Car_Sales_WebApp.Services.Interface;

namespace Car_Sales_WebApp.Services
{
    
    public class CarService : ICarService
    {
        private readonly IBaseService _baseService;
        public CarService(IBaseService baseService)
        {
            _baseService = baseService;
        }

        public async Task<Response?> GetAllCarsAsync()
        {
            return await _baseService.SendAsync(new Request()
            {
                ApiType = ApiType.GET,
                Url = SD.CarManagementAPIBase + "/api/cars/CarsList"
            }); 
        }

        public Response? GetAllBrands()
        {
            return  _baseService.Send(new Request()
            {
                ApiType = ApiType.GET,
                Url = SD.CarManagementAPIBase + "/api/cars/BrandList"
            });
        }

        public  Response? GetAllClass()
        {
            return  _baseService.Send(new Request()
            {
                ApiType = ApiType.GET,
                Url = SD.CarManagementAPIBase + "/api/cars/ClassList"
            });
        }

        public async Task<Response?> DeleteCarAsync(int id)
		{
			return await _baseService.SendAsync(new Request()
			{
				ApiType = ApiType.POST,
				Url = SD.CarManagementAPIBase + "/api/cars/DeleteCar/" + id
			});
		}

        public async Task<Response?> CreateCarAsync(CarModel carModel)
        {
            return await _baseService.SendAsync(new Request()
            {
                ApiType = ApiType.POST,
                Data = carModel,
                Url = SD.CarManagementAPIBase + "/api/cars/InsertUpdateCar"
            });
        }

        public Response? GetCarDetailsByID(int id)
        {
            return _baseService.Send(new Request()
            {
                ApiType = ApiType.GET,
                Url = SD.CarManagementAPIBase + "/api/cars/GetCarDetailsByID/" + id
            });
        }
    }
}
