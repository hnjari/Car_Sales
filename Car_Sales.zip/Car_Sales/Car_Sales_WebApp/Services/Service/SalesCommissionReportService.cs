﻿using Car_Sales_WebApp.Models;
using Car_Sales_WebApp.Services.Interface;

namespace Car_Sales_WebApp.Services
{
    
    public class SalesCommissionReportService : ISalesCommissionReportService
    {
        private readonly IBaseService _baseService;
        public SalesCommissionReportService(IBaseService baseService)
        {
            _baseService = baseService;
        }

        public async Task<Response?> Get_Salesman_Commission_ReportAsync()
        {
            return await _baseService.SendAsync(new Request()
            {
                ApiType = ApiType.GET,
                Url = SD.CarManagementAPIBase + "/api/SalesCommissionReport/Get_Salesman_Commission_Report/" 
            }); 
        }

      

       

    }
}
