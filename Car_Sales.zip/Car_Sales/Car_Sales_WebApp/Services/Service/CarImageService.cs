﻿using Car_Sales_WebApp.Models;
using Car_Sales_WebApp.Services.Interface;

namespace Car_Sales_WebApp.Services
{
    
    public class CarImageService : ICarImageService
    {
        private readonly IBaseService _baseService;
        public CarImageService(IBaseService baseService)
        {
            _baseService = baseService;
        }

        public async Task<Response?> GetAllCarImageAsync(int CarID)
        {
            return await _baseService.SendAsync(new Request()
            {
                ApiType = ApiType.GET,
                Url = SD.CarManagementAPIBase + "/api/carimage/GetCarImages/" + CarID
            }); ; 
        }

        public async Task<Response?> AddCarImageAsync(int CarID, string ImageName)
        {
            return await _baseService.SendAsync(new Request()
            {
                ApiType = ApiType.POST,
                Url = SD.CarManagementAPIBase + "/api/carimage/AddCarImage/" + CarID.ToString() + "/" + ImageName.ToString()
            }); 
        }

        public async Task<Response?> DeleteCarImageAsync(int id)
        {
            return await _baseService.SendAsync(new Request()
            {
                ApiType = ApiType.POST,
                Url = SD.CarManagementAPIBase + "/api/carimage/DeleteCarImage/" + id
            });
        }

    }
}
