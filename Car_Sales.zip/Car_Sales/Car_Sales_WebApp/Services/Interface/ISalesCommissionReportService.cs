﻿using Car_Sales_WebApp.Models;

namespace Car_Sales_WebApp.Services.Interface
{
    public interface ISalesCommissionReportService
    {
        public Task<Response?> Get_Salesman_Commission_ReportAsync();

        
    }
}
