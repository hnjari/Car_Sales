﻿using Car_Sales_WebApp.Models;

namespace Car_Sales_WebApp.Services.Interface
{
    public interface ICarImageService
    {
        public Task<Response?> GetAllCarImageAsync(int CarID);

        public Task<Response?> AddCarImageAsync(int CarID, string ImageName);

        public Task<Response?> DeleteCarImageAsync(int id);
    }
}
