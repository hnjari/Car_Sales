﻿using Car_Sales_WebApp.Models;

namespace Car_Sales_WebApp.Services.Interface
{
    public interface IBaseService
    {
        Task<Response?> SendAsync(Request request, bool withBearer = true);

        Response? Send(Request request, bool withBearer = true);
    }
}
