﻿using Car_Sales_WebApp.Models;

namespace Car_Sales_WebApp.Services.Interface
{
    public interface ICarService
    {
        public Task<Response?> GetAllCarsAsync();

		public Task<Response?> DeleteCarAsync(int id);

        public Response? GetAllBrands();

        public Response? GetAllClass();

        public Task<Response?> CreateCarAsync(CarModel carModel);

        public Response? GetCarDetailsByID(int id);
    }
}
